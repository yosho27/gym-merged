# gym-merged
Use OpenAI to play the mobile game Merged
